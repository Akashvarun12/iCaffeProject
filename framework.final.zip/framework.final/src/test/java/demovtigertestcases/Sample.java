package demovtigertestcases;

public class Sample {

	public static void main(String[] args) {
//
//		String str = "computer";
//		int countVovels = 0;
//		int countConsonant = 0;
//		String word = str.toLowerCase();
//		for (int i = 0; i <= word.length() - 1; i++) {
//
//		char	ch = word.charAt(i);
//
//		
//		if(Character.isLetter(ch)) {
//
//		if (!(ch == 'a' || ch == 'e' || ch == 'o' || ch == 'i' || ch == 'u')) {
//			countConsonant++;
//		} else {
//			countVovels++;
//		}
//		}
//		}
//		System.out.println("Number of vovels - " + countVovels);
//		System.out.println("Number of consonant - " + countConsonant);
app2();
	}

	public static void app2(){

		String str="AKASH123";
		int cousanantCount=0;
		String word=str.toUpperCase();
		for(int i=0;i<=word.length()-1;i++){
		char ch=word.charAt(i);
		if(Character.isLetter(ch)){
		if(!(ch=='A' || ch=='E' || ch=='I' || ch=='O' || ch=='U' )){
		cousanantCount++;
		}
		}
		}
		System.out.println("No Of Count - "+cousanantCount);
		}

}
